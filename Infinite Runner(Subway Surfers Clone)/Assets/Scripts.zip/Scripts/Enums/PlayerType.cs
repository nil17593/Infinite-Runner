﻿using UnityEditor;
using UnityEngine;

namespace IMPLIEDSOULS.InfiniteRunner
{
    public enum PlayerType
    {
        Fast,
        Slow,
    }
}